var slideIndex = 4;
showDivs(slideIndex);

function plusDivs(n) {
    showDivs(slideIndex += n);
}


function showDivs(n) {
    var i;
    var x = document.getElementsByClassName("mySlides"); 
    if (n > x.length) {slideIndex = 1}
    if (n < 1) {slideIndex = x.length} ;
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    x[slideIndex-1].style.display = "block";
   if (n === 1) {play("crowd");
    document.getElementById("content").style.background = "url('img/clap.gif') no-repeat center center";
    document.getElementById("content").style.backgroundSize = "100% 100%";
    document.getElementById("playagainW").style.display = "block";
    document.getElementById("instructions").style.color = "transparent";
}  
   if (n === 7) {play("explosion");
    document.getElementById("content").style.background = "url('img/nuke.gif') no-repeat center center";
    document.getElementById("content").style.backgroundSize = "100% 100%";
    document.getElementById("playagainL").style.display = "block";
    document.getElementById("instructions").style.color = "transparent";
}


}

function clickCounter() {
    if(typeof(Storage) !== "undefined") {
        if (localStorage.clickcount) {
            localStorage.clickcount = Number(localStorage.clickcount)+1;
        } else {
            localStorage.clickcount = 1;
        }
        document.getElementById("result").innerHTML = "Kim has been tickled " + localStorage.clickcount + " times.";
    } else {
        document.getElementById("result").innerHTML = "Sorry, your browser does not support web storage...";
    }
}

function play(element) {
          var audio = document.getElementById(element);
          audio.play()
      }

 
 function refresh() {
    location.reload();
}